angular.module("umbraco")
.controller("UmbracoForms.Dashboards.ActivityController",
	function ($scope, recordResource) {

		//var filter = {};
		//recordResource.getRecords(filter).then(function(response){
		//	$scope.records = response.data;
		//});

	});
